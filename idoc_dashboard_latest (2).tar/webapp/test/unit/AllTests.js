sap.ui.define([
	"com/sap/dashboard/db/idocdashboard/test/unit/controller/Overview.controller"
], function () {
	"use strict";
});
