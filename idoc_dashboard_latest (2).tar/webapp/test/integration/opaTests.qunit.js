/* global QUnit */
QUnit.config.autostart = false;

sap.ui.require(["com/sap/dashboard/db/idocdashboard/test/integration/AllJourneys"
], function () {
	QUnit.start();
});
