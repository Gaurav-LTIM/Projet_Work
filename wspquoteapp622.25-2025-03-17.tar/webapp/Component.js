sap.ui.define(
    ["sap/suite/ui/generic/template/lib/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("com.kelda.yw.ssc.fe.trx.wspquoteapp622.25.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);